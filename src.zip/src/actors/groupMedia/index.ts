import { run } from './actor';

const main = async () => {
  await run();
};

main();
