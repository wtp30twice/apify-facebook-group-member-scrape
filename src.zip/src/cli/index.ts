#!/usr/bin/env node
import { cli } from './cli';

cli();
